import Editor from './Video_Editor/VideoEditor'

function App() {
  return (
    <div className="App">
      <Editor />
    </div>
  );
}

export default App;